void setup() {
  size(600, 600);
  background(220, 230, 240); // Soft background
}

void draw() {
  
  // Base Layer
  noStroke();
  fill(180, 175, 160); // Pallas cat grey-beige
  ellipse(300, 400, 360, 360);   // THE BODY IS ROUND!
  ellipse(300, 250, 250, 200);  // Head
  ellipse(260, 550, 200, 70); // Tail
  triangle(185, 160, 200, 195, 225, 170);  // Left Ear
  triangle(415, 160, 400, 195, 375, 170);  // Right Ear
  
  // 2nd Layer
  // Head Spots
  fill(74, 52, 19);
  ellipse(300, 170, 20, 10);
  ellipse(280, 160, 20, 10);
  ellipse(320, 160, 20, 10);
  // 3rd Layer
  fill(250, 245, 225);
  ellipse(300, 280, 170, 100); 
  
  // Nose
  //stroke(0);
  fill(180, 175, 160); // Pallas cat grey-beige
  triangle(300, 214, 300-28, 252, 300+28, 252);
  fill(219, 145, 177);
  arc(300, 252, 24, 15, PI, TWO_PI);
  triangle(300 - 7, 252, 300 + 7,252, 300, 257);
  stroke(255);
  
  // Whiskers (Left)
  line(250, 260, 150, 260);
  line(250, 270, 150, 280);
  line(250, 280, 150, 300);
  // Whiskers (Right)
  line(350, 255, 450, 260);
  line(350, 265, 450, 280);
  line(350, 275, 450, 300);
  
  // Mouth
  noFill();
  stroke(0);
  arc(300 - 12, 265, 24, 15, 0 , PI - PI/4);
  arc(300 + 12, 265, 24, 15, 0 + PI/4, PI);
  
  // Eyes
  fill(215, 235, 160); 
  stroke(0);
  strokeWeight(3);
  ellipse(300 - 30, 220, 30, 27);
  ellipse(300 + 30, 220, 30, 27);
  circle(300 - 30, 220, 3);
  circle(300 + 30, 220, 3);
  
  stroke(74, 52, 19);
  noFill();
  arc(300 - 35, 210, 30, 27, PI, TWO_PI - PI/3); // Left Brow
  arc(300 + 35, 210, 30, 27, PI + PI/3, TWO_PI); // Right Brow
  
  // Arms and Paws
  arc(100, 540, 400, 500, TWO_PI - PI/4, TWO_PI); // Left
  arc(500, 540, 400, 500, PI, PI + PI/4);         // Right
  noStroke();
  fill(245, 221, 186);  // Light Orange Fur
  arc(300 - 30, 540, 60, 40, PI - QUARTER_PI, TWO_PI + QUARTER_PI, CHORD);
  arc(300 + 30, 540, 60, 40, PI - QUARTER_PI, TWO_PI + QUARTER_PI, CHORD);
  
  
  
}
